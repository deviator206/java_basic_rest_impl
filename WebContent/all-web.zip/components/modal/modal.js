'use strict';
angular.module('salesApp.modal', [
  'salesApp.modal.print-modal-directive'
])
